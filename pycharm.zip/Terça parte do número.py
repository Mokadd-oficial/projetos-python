# 10 numeros aleatorios

import random as rnd

seq = rnd.sample(range(1, 100),10)
print (seq)

for i in range(0,10):
    print (seq[i]/3)

