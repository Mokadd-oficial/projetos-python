# plv = str(input("Escreva algo:\n")).lower()
#
# vogais = "aeiouAEIOU"
# vogal = 0
# consoante = 0
#
# for i in plv:
#     if i in vogais:
#         vogal +=1
#     if i != " " and i not in vogais:
#         consoante +=1
# print(f' a sua frase tem {vogal} e {consoante} cnsoantes')

plv = str(input("Escreva algo:\n")).lower()

vogais = "aeiouAEIOU"
vogal = 0
consoante = 0

for i in plv:
    if i in vogais:
        vogal +=1
    elif i != " ":
        consoante +=1
print(f' a sua frase tem {vogal} e {consoante} consoante')
