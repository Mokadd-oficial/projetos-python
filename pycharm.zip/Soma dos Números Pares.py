numero = int(input(f"insira um número inteiro: \n"))
soma = 0

for i in range(1, numero + 1):
    if i % 2 == 0:
        soma += i
print(soma)


