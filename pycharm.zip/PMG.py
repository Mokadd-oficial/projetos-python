x = int(input("coloque um número: "))
y = int(input("coloque mais um número: "))
z = int(input("coloque mais um número: "))
#
# if x>y:
#     temp = x
#     x = y
#     z = temp
#
# if x > z:
#     temp = x
#     x = z
#     z = temp
# if y>z:
#     temp = y
#     y = z
#     z = temp
# print (f'Menor: {x}, intermediario: {y}, maior: {z} ')

if x>y:
     x, y = y, x
if x>z:
    x, z = z, x
if y>z:
    y, z = z, y

print (f'Menor: {x}, intermediario: {y}, maior: {z} ')
