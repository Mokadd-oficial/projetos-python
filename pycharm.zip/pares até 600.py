print ("boa tarde, vamos ver os números pares até 600")
for i in range (2,601,2):
    print (i)
