#VERSÃO COM WHILE COMPLETO
bs = int(input("coloque um número base: "))
expo = int(input("coloque um número expoente: "))
#
# count = 1
total = 1
#
# while count <= expo:
#     total = total * bs
#     count = count +1 # sempre que o laço se repetir esse n aumenta
#
# print (f'{bs} elevado {expo} é {total}')

#VERSÃO COM FOR COMPLETO

for i in range (expo):
    total = total * bs

print (f'{bs} elevado {expo} é {total}')
