while True:
    primo = True
    numero = print (int(input("vamos ve se seu número é primo, insira um número inteiro: ")))

    for i in range(2, numero-1):
      if numero % i == 0:
         primo = False
break

    if primo:
    print(f'{numero} é primo')
    else:
    print(f'{numero} não é primo')

